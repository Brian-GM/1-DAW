/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package bgm.ieslaencanta.com.eed.tema3.p6;

/**
 *
 * @author DAWTarde
 */
public class Main {

    public static final int ERROR = 0;
    public static final int D1 = 11;
    public static final int D2 = 12;
    public static final int E1 = 21;
    public static final int E2 = 22;

    public boolean numero = false;
    public boolean letra = false;
    public boolean mayus = false;
    public boolean caracter_especial = false;

    public boolean directivo_valido = false;

    public static void main(String[] args) {
    }

    public int categoria(
            String codigoEmpleado,
            int mesesTrabajado,
            String directivo) {
        if (codigoEmpleado == null || directivo == null) {
            return ERROR;
        }
        if (mesesTrabajado < 0 || mesesTrabajado > 999) {
            return ERROR;
        }

        for (int i = 0; i < codigoEmpleado.length() - 1; i++) {
                        char c = codigoEmpleado.charAt(i);

            if (c >= '0' && c <= '9') {
                numero = true;
            } else if (c >= 'a' && c <= 'z') {
                letra = true;
            } else if ((c >= 'A' && c <= 'Z') && mayus == false) {
                mayus = true;
            } else{
          caracter_especial = true;
            }
        }
         if (directivo.equals("+")){
             directivo_valido = true;
            }else if (directivo.equals("-")){
            directivo_valido = true;
            }else{
            directivo_valido = false;
            }

        if (numero == false && letra == true || numero == true && letra == false || mayus == true || caracter_especial == true || directivo_valido == false) {
            return ERROR;

        } else {
        }
        boolean esDirectivo = directivo.equals("+");

        if (mesesTrabajado > 12) {
            if (esDirectivo == true) {
                return D1;
            } else {
                return E1;
            }
        } else {
            if (esDirectivo == true) {
                return D2;
            } else {
                return E2;
            }
        }
    }

}
