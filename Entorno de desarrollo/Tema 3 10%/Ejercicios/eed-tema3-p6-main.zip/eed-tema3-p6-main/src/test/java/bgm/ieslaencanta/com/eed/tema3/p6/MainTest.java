/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package bgm.ieslaencanta.com.eed.tema3.p6;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author DAWTarde
 */
public class MainTest {
    
    public MainTest() {
    }

    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

   

    /**
     * Test of categoria method, of class Main.
     */
    @Test
    public void testCategoria_direc_mas_12_meses() {
        Main main = new Main();
        int resultado = main.categoria("2ef4", 15, "+");
        assertEquals( Main.D1, resultado);
    }
     @Test
    public void testCategoria_cod_emple_solo_letras() {
        Main main = new Main();
        int resultado = main.categoria("abdcef", 15, "+");
        assertEquals( Main.ERROR, resultado);
    }
       @Test
    public void testCategoria_cod_emple_solo_num() {
        Main main = new Main();
        int resultado = main.categoria("12345", 15, "+");
        assertEquals( Main.ERROR, resultado);
    }
        @Test
    public void testCategoria_cod_emple_num_let_may() {
        Main main = new Main();
        int resultado = main.categoria("1a23BC", 15, "+");
        assertEquals( Main.ERROR, resultado);
    }
    
     @Test
    public void testCategoria_cod_emple_caracter_especial() {
        Main main = new Main();
        int resultado = main.categoria("#1f234g", 15, "+");
        assertEquals( Main.ERROR, resultado);
    }
    
     @Test
    public void testCategoria_meses_negativos() {
        Main main = new Main();
        int resultado = main.categoria("fe4a5b", -5, "+");
        assertEquals( Main.ERROR, resultado);
    }
    
     @Test
    public void testCategoria_meses_mas_de_999 () {
        Main main = new Main();
        int resultado = main.categoria("fe4a5b", 2345, "+");
        assertEquals( Main.ERROR, resultado);
    }
    
     @Test
    public void testCategoria_no_direct_mas_12_meses() {
        Main main = new Main();
        int resultado = main.categoria("1a2b3c", 23, "-");
        assertEquals( Main.E1, resultado);
    }
    
     @Test
    public void testCategoria_direct_caracter_no_valido(){
        Main main = new Main();
        int resultado = main.categoria("1a2b3c", 23, "b");
        assertEquals( Main.ERROR, resultado);
    }
    
     @Test
    public void testCategoria_direct_mas_caracter_no_valido(){
        Main main = new Main();
        int resultado = main.categoria("1a2b3c", 23, "235+");
        assertEquals( Main.ERROR, resultado);
    }
    
     @Test
    public void testCategoria_no_direct_mas_caracter_no_valido(){
        Main main = new Main();
        int resultado = main.categoria("1a2b3c", 23, "23-5");
        assertEquals( Main.ERROR, resultado);
    }
    
     @Test
    public void testCategoria_directivo_no_valido(){
        Main main = new Main();
        int resultado = main.categoria("1a2b3c", 23, "directivo");
        assertEquals( Main.ERROR, resultado);
    }
    
     @Test
    public void testCategoria_directivo_menos_12_meses() {
        Main main = new Main();
        int resultado = main.categoria("1a2b3c", 5, "+");
        assertEquals( Main.D2, resultado);
    }
    
     @Test
    public void testCategoria_no_directivo_menos_12_meses() {
        Main main = new Main();
        int resultado = main.categoria("1a2b3c", 5, "-");
        assertEquals( Main.E2, resultado);
    }
        //Casos limite

     @Test
    public void testCategoria_limite_meses_tabajados_abajo(){
        Main main = new Main();
        int resultado = main.categoria("1a2b3c", -1, "+");
        assertEquals( Main.ERROR, resultado);
    }
     @Test
    public void  testCategoria_limite_meses_tabajados_abajo_frontera(){
        Main main = new Main();
        int resultado = main.categoria("1a2b3c", 0, "+");
        assertEquals( Main.D2, resultado);
    }
       
     @Test
    public void testCategoria_limite_meses_tabajados_arriba(){
        Main main = new Main();
        int resultado = main.categoria("1a2b3c", 999, "+");
        assertEquals( Main.D1, resultado);
    }
    
     @Test
    public void  testCategoria_limite_meses_tabajados_arriba_frontera(){
        Main main = new Main();
        int resultado = main.categoria("1a2b3c", 1000, "+");
        assertEquals( Main.ERROR, resultado);
    }
}
