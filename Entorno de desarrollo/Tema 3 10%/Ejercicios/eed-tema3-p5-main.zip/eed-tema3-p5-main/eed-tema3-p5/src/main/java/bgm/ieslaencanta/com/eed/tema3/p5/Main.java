/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package bgm.ieslaencanta.com.eed.tema3.p5;

/**
 *
 * @author DAWTarde
 */
public class Main {
    
    private static final int ERROR = 0;
    private static final int D1 = 11;
    private static final int D2 = 12;
    private static final int E1 = 21;
    private static final int E2 = 22;

    public static void main(String[] args) {
        Main programa = new Main();
        int resultado = Main.categoria("fds394", 32, "+");
        System.out.println(resultado);
    }
    
    public static int categoria(
		String codigoEmpleado,
		int mesesTrabajado,
		String directivo) {
        if (codigoEmpleado == null || directivo == null) {
            return ERROR;
        }
        
        if (mesesTrabajado < 0) {
            return ERROR;
        }
        
        boolean esDirectivo = directivo.equals("+");
        
        if (mesesTrabajado < 12) {
            if (esDirectivo) {
                return E1;
            } else {
                return D1;
            }
        } else {
            if (esDirectivo) {
                return E2;
            } else {
                return D2;
            }
        }
    }
}