/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package pedro.ieslaencanta.com.chess.model;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import pedro.ieslaencanta.com.chess.controller.Game;
import pedro.ieslaencanta.com.chess.model.ChessPiece.King;

/**
 *
 * @author DAWTarde
 */
public class BoardTest {

    public BoardTest() {
    }

    @BeforeAll
    public static void setUpClass() {
    }

    @AfterAll
    public static void tearDownClass() {
    }

    @BeforeEach
    public void setUp() {
    }

    @AfterEach
    public void tearDown() {
    }

    @Test
    public void testGetCellColEntre07() {
        Board board = new Board();
        Cell celda = board.getCell(1, 3);
        assertTrue(celda instanceof Cell);
    }

    @Test
    public void testGetCellColMenor0() {
        Board board = new Board();
        Cell celda = board.getCell(1, -3);
        assertNull(celda);
    }

    @Test
    public void testGetCellColMayor7() {
        Board board = new Board();
        Cell celda = board.getCell(1, 10);
        assertNull(celda);
    }

    @Test
    public void testGetCellRowEntre07() {
        Board board = new Board();
        Cell celda = board.getCell(3, 1);
        assertTrue(celda instanceof Cell);
    }

    @Test
    public void testGetCellRowMenor0() {
        Board board = new Board();
        Cell celda = board.getCell(-3, 1);
        assertNull(celda);
    }

    @Test
    public void testGetCellRowMayor7() {
        Board board = new Board();
        Cell celda = board.getCell(10, 1);
        assertNull(celda);
    }

//Valores limite
    @Test
    public void testGetCellColLimi1() {
        Board board = new Board();
        Cell celda = board.getCell(1, -1);
        assertNull(celda);
    }

    @Test
    public void testGetCellColLimi2() {
        Board board = new Board();
        Cell celda = board.getCell(1, 0);
        assertTrue(celda instanceof Cell);
    }

    @Test
    public void testGetCellColLimi3() {
        Board board = new Board();
        Cell celda = board.getCell(1, 7);
        assertTrue(celda instanceof Cell);
    }

    @Test
    public void testGetCellColLimi4() {
        Board board = new Board();
        Cell celda = board.getCell(1, 8);
        assertNull(celda);
    }

    @Test
    public void testGetCellRowLimi1() {
        Board board = new Board();
        Cell celda = board.getCell(-1, 1);
        assertNull(celda);
    }

    @Test
    public void testGetCellRowLimi2() {
        Board board = new Board();
        Cell celda = board.getCell(0, 1);
        assertTrue(celda instanceof Cell);
    }

    @Test
    public void testGetCellRowLimi3() {
        Board board = new Board();
        Cell celda = board.getCell(7, 1);
        assertTrue(celda instanceof Cell);
    }

    @Test
    public void testGetCellRowLimi4() {
        Board board = new Board();
        Cell celda = board.getCell(8, 1);
        assertNull(celda);
    }
//Test Move

    @Test
    public void testMoveStartRowMenor7() {
        Board board = new Board();
        Move p = board.move(-2, 5, 1, 1);
        assertNull(p);

    }

    @Test
    public void testMovePositivo() {
        Board board = new Board();
        Move p = board.move(1, 1, 1, 2);
        assertTrue(p instanceof Move);
    }

    @Test
    public void testMoveStartRowMayor7() {
        Board board = new Board();
        Move p = board.move(8, 1, 1, 1);
        assertNull(p);
    }

    @Test
    public void testMoveEndRowMenor7() {
        Board board = new Board();
        Move p = board.move(1, 1, -2, 5);
        assertNull(p);

    }

    @Test
    public void testMoveEndRowMayor7() {
        Board board = new Board();
        Move p = board.move(1, 2, 1, 8);
        assertNull(p);
    }

    @Test
    public void testMoveNull() {
        Board board = new Board();
        Move p = board.move(2, 3, 2, 4);
        assertNull(p);
    }

    @Test
    public void testMoveNull2() {
        Board board = new Board();
        Move p = board.move(5, 0, 4, 0);
        assertFalse(p instanceof Move);
    }

    //Casos limite
    @Test
    public void testMoveStartRowMenosUno() {
        Board board = new Board();
        Move p = board.move(-1, 0, 1, 1);
        assertNull(p);
    }

    @Test
    public void testMoveStartColMenosUno() {
        Board board = new Board();
        Move p = board.move(0, -1, 1, 1);
        assertNull(p);
    }

    @Test
    public void testMoveStartColStartRowCero() {
        Board board = new Board();
        Move p = board.move(0, 0, 1, 1);
        assertTrue(p instanceof Move);
    }
   @Test
    public void testMoveStartColStartRowSiete() {
        Board board = new Board();
        Move p = board.move(7, 7, 1, 1);
        assertTrue(p instanceof Move);
    }
      @Test
    public void testMoveStartRowOcho() {
        Board board = new Board();
        Move p = board.move(8, 7, 1,1);
        assertNull(p);
    }
      @Test
    public void testMoveStartColOcho() {
        Board board = new Board();
        Move p = board.move(7, 8, 1, 1);
        assertNull(p);
    }
    
     @Test
    public void testMoveEndRowMenosUno() {
        Board board = new Board();
        Move p = board.move(1,1,-1,0);
        assertNull(p);
    }

    @Test
    public void testMoveEndColMenosUno() {
        Board board = new Board();
        Move p = board.move(1,1,0,-1);
        assertNull(p);
    }

    @Test
    public void testMoveEndColEndRowCero() {
        Board board = new Board();
        Move p = board.move(1, 1,0, 0);
        assertTrue(p instanceof Move);
    }
   @Test
    public void testMoveEndColEndRowSiete() {
        Board board = new Board();
        Move p = board.move(1, 1,7, 7);
        assertTrue(p instanceof Move);
    }
      @Test
    public void testMoveEndRowOcho() {
        Board board = new Board();
        Move p = board.move(1,1,8,7);
        assertNull(p);
    }
      @Test
    public void testMoveEndColOcho() {
        Board board = new Board();
        Move p = board.move(1, 1, 7, 8);
        assertNull(p);
    }
}
