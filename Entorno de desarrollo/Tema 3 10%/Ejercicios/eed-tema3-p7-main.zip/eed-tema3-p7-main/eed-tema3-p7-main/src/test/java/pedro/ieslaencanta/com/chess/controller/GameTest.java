/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package pedro.ieslaencanta.com.chess.controller;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import pedro.ieslaencanta.com.chess.model.Board;
import pedro.ieslaencanta.com.chess.model.ChessPiece.PieceType;
import pedro.ieslaencanta.com.chess.model.Move;

/**
 *
 * @author DAWTarde
 */
public class GameTest {
    
    public GameTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }
    /**
     * Test of canMove method, of class Game.
     */
    @Test
    public void testCanMoveSiPuedesMover() {
      Game game = new Game();
    
     boolean resultado = game.canMove(6, 0, 5, 0);
        assertEquals( true, resultado);
    }


 @Test
    public void testCanMoveNoFichaSeleccionada() {
      Game game = new Game();
    
     boolean resultado = game.canMove(4, 0, 3, 0);
        assertEquals( false, resultado);
    }
  @Test
    public void testCanMoveNoEsTuTurno() {
      Game game = new Game();
    
     boolean resultado = game.canMove(0, 0, 1, 0);
        assertEquals( false, resultado);
    }
    
}
