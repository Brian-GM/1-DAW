
public class BotonWeb implements Boton {

    public void renderizar() {

    }

    public void onClic() {

    }
}
