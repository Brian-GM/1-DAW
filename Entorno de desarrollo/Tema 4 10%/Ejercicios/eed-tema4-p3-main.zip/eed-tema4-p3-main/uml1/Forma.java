
public abstract class Forma {

    private int x;
    private int y;
    private String color;

    public void Forma(int fuente){
        
    }
    
    public abstract void clonar();
}
