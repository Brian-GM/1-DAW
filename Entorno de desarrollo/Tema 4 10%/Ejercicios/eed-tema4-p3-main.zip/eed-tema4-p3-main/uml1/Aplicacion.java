
public class Aplicacion {
    private List <Forma> formas;
}
