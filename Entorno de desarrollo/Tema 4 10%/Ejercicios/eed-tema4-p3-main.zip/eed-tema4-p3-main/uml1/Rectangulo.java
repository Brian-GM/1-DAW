
public class Rectangulo extends Forma{
    public int ancho;
    public int alto;
    
    public void Rectangulo(){
        
    }

    @Override
    public void clonar() {
    }
    
}
