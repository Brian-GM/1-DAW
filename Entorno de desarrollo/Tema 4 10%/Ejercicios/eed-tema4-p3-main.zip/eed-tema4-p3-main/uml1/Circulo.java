
public class Circulo extends Forma{
    public float radio;
    
    public void Clonar(){
        
    }

    @Override
    public void clonar() {
    }
}
