# Práctica de Entornos de Desarrollo
En esta práctica usarán las opciones de trabajo colaborativo en GitHub: aprenderán a usar el Fork y los Pull Request.
