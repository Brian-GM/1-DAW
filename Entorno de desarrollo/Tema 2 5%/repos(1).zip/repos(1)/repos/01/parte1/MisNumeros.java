class MisNumeros {
    private int num1;
    private int num2;

    /**
     * constructor por defecto.
     */
    public MisNumeros() {
        this.num1 = 0;
        this.num2 = 0;
    }
}