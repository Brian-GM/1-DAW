# Descripción
Se trata de un programa absurdo, escrito en Java, que no hace nada.