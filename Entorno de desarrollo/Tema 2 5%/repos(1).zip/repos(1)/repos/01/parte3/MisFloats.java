class MisFloats {
    private float num1;
    private float num2;

    public MisFloats() {
        this.num1 = 0f;
        this.num2 = 0f;
    }
}