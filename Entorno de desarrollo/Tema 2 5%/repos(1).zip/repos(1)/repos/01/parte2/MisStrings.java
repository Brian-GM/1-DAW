class MisStrings {
    private String str1;
    private String str2;

    /**
     * constructor por defecto.
     */
    public MisStrings() {
        this.str1 = "";
        this.str2 = "";
    }
}