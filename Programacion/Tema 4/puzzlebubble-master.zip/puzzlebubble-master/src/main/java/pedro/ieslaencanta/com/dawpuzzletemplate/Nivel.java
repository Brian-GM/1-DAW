package pedro.ieslaencanta.com.dawpuzzletemplate;


import javafx.geometry.Dimension2D;
import javafx.geometry.Point2D;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import pedro.ieslaencanta.com.dawpuzzletemplate.Bubble;
import pedro.ieslaencanta.com.dawpuzzletemplate.BubbleType;
import pedro.ieslaencanta.com.dawpuzzletemplate.Game;
import pedro.ieslaencanta.com.dawpuzzletemplate.Resources;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author brian
 */
public class Nivel {
    

private Dimension2D original_size;    
private GraphicsContext gc;
private GraphicsContext bggc;
private Nivel niveles [] = new Nivel[9];
private Point2D topposition = new Point2D(1,2); 
private int WIDTH;
private int HEIGHT;
private int starty;

    public Nivel() {
    }
    public Nivel(int WIDTH, int HEIGHT,Point2D position) {
        this.WIDTH = WIDTH;
        this.HEIGHT = HEIGHT;
        this.topposition = position;
    }

    /**
     * @return the niveles
     */
    public Nivel[] getNiveles() {
        return niveles;
    }

    /**
     * @param niveles the niveles to set
     */
    public void setNiveles(Nivel[] niveles) {
        this.niveles = niveles;
    }

    /**
     * @return the topposition
     */
    public Point2D getTopposition() {
        return topposition;
    }

    /**
     * @param topposition the topposition to set
     */
    public void setTopposition(Point2D topposition) {
        this.topposition = topposition;
    }

    /**
     * @return the WIDTH
     */
    public int getWIDTH() {
        return WIDTH;
    }

    /**
     * @param WIDTH the WIDTH to set
     */
    public void setWIDTH(int WIDTH) {
        this.WIDTH = WIDTH;
    }

    /**
     * @return the HEIGHT
     */
    public int getHEIGHT() {
        return HEIGHT;
    }

    /**
     * @param HEIGHT the HEIGHT to set
     */
    public void setHEIGHT(int HEIGHT) {
        this.HEIGHT = HEIGHT;
    }

    /**
     * @return the starty
     */
    public int getStarty() {
        return starty;
    }

    /**
     * @param starty the starty to set
     */
    public void setStarty(int starty) {
        this.starty = starty;
    }
   
      public void paintBackground() {
      

}
}