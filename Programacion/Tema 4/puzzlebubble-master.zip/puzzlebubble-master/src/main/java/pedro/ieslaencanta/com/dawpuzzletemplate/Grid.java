package pedro.ieslaencanta.com.dawpuzzletemplate;

import javafx.geometry.Point2D;
import javafx.scene.canvas.GraphicsContext;
import static javafx.scene.paint.Color.color;

/**
 *
 * @author DAWTarde
 */
public class Grid {

    private boolean colision = false;
    private int startx = 0;
    private int starty = 0;
    private static int WIDTH = 9, HEIGHT = 12;
    private Bubble grid[][];
    int resultado[] = new int[20];

    public Grid() {
        this.grid = new Bubble[HEIGHT][WIDTH];

    }

    public Grid(int startx, int starty) {
        this.grid = new Bubble[HEIGHT][WIDTH];
        this.startx = startx;
        this.starty = starty;

    }

    public Grid(BubbleType bubbles[][], int startx, int starty) {

    }

    /**
     * @return the startx
     */
    public int getStartx() {
        return startx;
    }

    /**
     * @param startx the startx to set
     */
    public void setStartx(int startx) {
        this.startx = startx;
    }

    /**
     * @return the starty
     */
    public int getStarty() {
        return starty;
    }

    /**
     * @param starty the starty to set
     */
    public void setStarty(int starty) {
        this.starty = starty;
    }

    public boolean collision(Bubble b) {
        int columna, fila;
        boolean collision = false;
        if (b != null) {
            for (int i = 0; i < this.grid.length && !collision; i++) {
                for (int j = 0; j < this.grid[i].length && !collision; j++) {
                    if (b.getPosicion().getY() - (Bubble.WIDTH / 2) <= this.starty) {
                        b.stop();
                        //sacamos la columna y la fila en la que esta la burbuja
                        columna = (int) ((b.getPosicion().getX() - this.startx) / Bubble.WIDTH);
                        fila = 0;//(int) ((b.getPosicion().getY() - this.starty) / Bubble.HEIGHT);
                        this.grid[fila][columna] = b;
                        //Ponemos la burbuja en la nueva posicion
                        b.setPosicion(
                                new Point2D(
                                        this.startx + columna * Bubble.WIDTH + Bubble.WIDTH / 2,
                                        this.starty + fila * Bubble.HEIGHT + Bubble.HEIGHT / 2)
                        );
                        return true;
                    } else if (this.grid[i][j] != null
                            && this.grid[i][j].getPosicion().distance(b.getPosicion()) <= 16) {
                        b.stop();
                        columna = (int) ((b.getPosicion().getX() - this.startx)  / Bubble.WIDTH);
                        fila = (int) ((b.getPosicion().getY() - this.starty) / Bubble.HEIGHT);
                        this.grid[fila][columna] = b;
                        if (fila % 2 == 0) {
                            b.setPosicion(
                                    new Point2D(
                                            this.startx + columna * Bubble.WIDTH + Bubble.WIDTH / 2,
                                            this.starty + fila * Bubble.HEIGHT + Bubble.HEIGHT / 2)
                            );
                        } else {
                             b.setPosicion(
                                    new Point2D(
                                            this.startx + columna * Bubble.WIDTH + Bubble.WIDTH,
                                            this.starty + fila * Bubble.HEIGHT + Bubble.HEIGHT / 2)
                            );
                        }
                        return true;
                    } else {

                    }
                }
            }
        }
        return false;

    }

    public boolean eval(int resultado[], int x, int y, BubbleType color) {
        int columna, fila;
        columna = ((x - this.startx) / Bubble.WIDTH);
        fila = ((y - this.starty) / Bubble.HEIGHT);

        if (fila % 2 == 0) {//Lineas par
            System.out.println(" ");
            if (columna - 1 >= 0 && grid[fila][columna - 1] != null) {//Izquierda
                if (grid[fila][columna - 1].getBalltype() == color) {
                } else {
                }
            }
            if (columna + 1 < grid[1].length && grid[fila][columna + 1] != null) {//Derecha
                if (grid[fila][columna + 1].getBalltype() == color) {
                } else {
                }
            }
            if (fila + 1 < grid.length && grid[fila + 1][columna] != null) {//Abajo
                if (grid[fila + 1][columna].getBalltype() == color) {
                } else {
                }
            }
            if (fila - 1 >= 0 && grid[fila - 1][columna] != null) {//Arriba
                if (grid[fila - 1][columna].getBalltype() == color) {
                } else {
                }
            }
            if (fila + 1 < grid.length && columna - 1 >= 0 && grid[fila + 1][columna - 1] != null) {//Izquierda abajo
                if (grid[fila + 1][columna - 1].getBalltype() == color) {
                } else {
                }
            }
            if (fila - 1 > 0 && columna - 1 >= 0 && grid[fila - 1][columna - 1] != null) {//Izquierda arriba
                if (grid[fila - 1][columna - 1].getBalltype() == color) {
                } else {
                }
            }
            return false;
        } else {//Lineas inpar
            System.out.println(" ");

            if (columna + 1 < grid[1].length && grid[fila][columna + 1] != null) {//Derecha
                if (grid[fila][columna + 1].getBalltype() == color) {
                } else {
                }
            }
            if (fila + 1 < grid.length && grid[fila + 1][columna] != null) {//Abajo
                if (grid[fila + 1][columna].getBalltype() == color) {
                } else {
                }
            }
            if (fila - 1 >= 0 && grid[fila - 1][columna] != null) {//Arriba
                if (grid[fila - 1][columna].getBalltype() == color) {
                } else {
                }
            }
            if (fila + 1 < grid.length && columna + 1 >= 0 && grid[fila + 1][columna + 1] != null) {//Izquierda abajo
                if (grid[fila + 1][columna + 1].getBalltype() == color) {
                } else {
                }
            }
            if (fila + 1 > 0 && columna - 1 >= 0 && grid[fila + 1][columna - 1] != null) {//Izquierda arriba
                if (grid[fila + 1][columna - 1].getBalltype() == color) {
                } else {
                }
            }//fallo linea impar izquierda siempre entra
            if (columna - 1 >= 0 && grid[fila][columna - 1] != null) {//Izquierda
                if (grid[fila][columna - 1].getBalltype() == color) {
                } else {
         
                }
            }
        }

        return false;
    }
public void eliminar_buble(){
     for (int i = 0; i < this.grid.length; i++) {
            for (int j = 0; j < this.grid[1].length; j++) {
                this.grid[i][j] = null;
             
            }
}
}
public boolean comprobar_campo(){

     for (int j = 0; j <= 8; j++) {
                if (this.grid[8][j] != null){

                    return true;
                }
     }
                        return false;
}

      




    public void paint(GraphicsContext gc) {
        for (int i = 0; i < this.grid.length; i++) {
            for (int j = 0; j < this.grid[1].length; j++) {
                if (this.grid[i][j] != null) {
                    this.grid[i][j].paint(gc);
                }
            }
        }
    }
}