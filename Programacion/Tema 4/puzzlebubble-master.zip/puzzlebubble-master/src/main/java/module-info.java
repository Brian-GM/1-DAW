module pedro.ieslaencanta.com.dawpuzzletemplate {
    requires javafx.controls;
    requires javafx.media;
    exports pedro.ieslaencanta.com.dawpuzzletemplate;
}
