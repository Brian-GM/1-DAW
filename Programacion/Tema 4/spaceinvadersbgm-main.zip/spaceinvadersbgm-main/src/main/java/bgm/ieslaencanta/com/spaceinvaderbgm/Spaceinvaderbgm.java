/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package bgm.ieslaencanta.com.spaceinvaderbgm;

/**
 *
 * @author DAWTarde
 */
public class Spaceinvaderbgm {

    public static void main(String[] args) {
Game game= new Game();
game.loop();
    }
}
