/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Tema_2;

import java.util.Scanner;

/**
 *
 * @author DAWTarde
 */
public class Ejercicio_3_3_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int fila, columna;
        Scanner teclado = new Scanner(System.in);
        System.out.println("Introduzca el numero de filas");
        fila = teclado.nextInt();
        columna = fila * 2;
        for (int i = 0; i <= fila; i++) {
            for (int j = 0; j <= columna; j++) {
                if (j>=columna/2-i && j<=columna/2+i) {
                    System.out.print("*");
                } else {

                    System.out.print("-");

                    {
                    }
                }
                // TODO code application logic here
            }
            System.out.println("");  
        }
    }
}
