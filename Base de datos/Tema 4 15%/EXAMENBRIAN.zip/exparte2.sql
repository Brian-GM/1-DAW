DROP DATABASE IF EXISTS jardineria;
CREATE DATABASE jardineria;
USE jardineria;

CREATE TABLE IF NOT EXISTS GAMA_PRODUCTO (
gama VARCHAR (50) ,
descripcion_texto TEXT,
descripcion_html TEXT,
imagen VARCHAR (256), 
CONSTRAINT PK_GAP PRIMARY KEY (gama)
);


CREATE TABLE IF NOT EXISTS OFICINA (
codigo_oficina VARCHAR(10),
ciudad VARCHAR (30),
pais VARCHAR (50),
region VARCHAR (50) NULL,
codigo_postal VARCHAR (10),
telefono VARCHAR (20),
linea_direccion1 VARCHAR (50),
linea_direccion2 VARCHAR (50) NULL,
CONSTRAINT PK_CLI PRIMARY KEY (codigo_oficina)
);

CREATE TABLE IF NOT EXISTS PRODUCTO (
codigo_producto VARCHAR (15) ,
nombre VARCHAR (70),
gama VARCHAR (50)  ,
dimesiones VARCHAR (25),
proveedor VARCHAR (50) NULL,
descripcion TEXT,
cantidad_en_stock SMALLINT(6),
precio_venta DECIMAL(15,2),
precio_proveedor DECIMAL(15,2) NULL,
CONSTRAINT PK_PRO PRIMARY KEY (codigo_producto),
CONSTRAINT FK_PRO_GAP FOREIGN KEY (gama) REFERENCES GAMA_PRODUCTO (gama),
CONSTRAINT CK_PRO_PREV CHECK (precio_venta > 0),
CONSTRAINT CK_PRO_PREP CHECK (precio_proveedor > 0),
CONSTRAINT CK_PRODU_PRE CHECK (cantidad_en_stock>0)
);

CREATE TABLE IF NOT EXISTS EMPLEADO (
codigo_empleado INT (11),
nombre VARCHAR(50),
apellido1 VARCHAR(50),
apellido2 VARCHAR(50) NULL,
extension VARCHAR(10),
email VARCHAR(100),
codigo_oficina VARCHAR(10),
codigo_jefe INT (11) NULL,
puesto VARCHAR (50) NULL,
CONSTRAINT PK_CLI PRIMARY KEY (codigo_empleado),
CONSTRAINT FK_EMP_OFC FOREIGN KEY (codigo_oficina) REFERENCES OFICINA (codigo_oficina)
);

CREATE TABLE IF NOT EXISTS CLIENTE (
codigo_cliente INT (11),
nombre_cliente VARCHAR(50),
nombre_contacto VARCHAR (30) NULL ,
apellido_contacto VARCHAR (30) NULL ,
telefono VARCHAR (15),
fax VARCHAR (15),
linea_direccion1 VARCHAR (50),
linea_direccion2 VARCHAR(50) NULL,
ciudad VARCHAR (50),
region VARCHAR (50),
pais VARCHAR (50),
codigo_postal VARCHAR (10) NULL,
codigo_empleado_rep_ventas INT (11) NULL,
limite_credito DECIMAL (15,2) NULL,
CONSTRAINT PK_CLI PRIMARY KEY (codigo_cliente),
CONSTRAINT FK_CLI_EMP FOREIGN KEY (codigo_empleado_rep_ventas) REFERENCES EMPLEADO (codigo_empleado)

);
CREATE TABLE IF NOT EXISTS PEDIDO (
codigo_pedido INT (11),
fecha_pedido DATE, 
fecha_esperada DATE,
fecha_entrega DATE NULL,
estado VARCHAR (15),
comentarios TEXT,
codigo_cliente INT (11),
CONSTRAINT PK_PED PRIMARY KEY (codigo_pedido),
CONSTRAINT FK_PED_CLI FOREIGN KEY (codigo_cliente) REFERENCES CLIENTE (codigo_cliente)

);
CREATE TABLE IF NOT EXISTS DETALLE_PEDIDO (
codigo_pedido INT (11),
codigo_producto VARCHAR (15),
cantidad INT (11),
precio_unidad DECIMAL(15,2),
numero_linea SMALLINT(6),
CONSTRAINT PK_DEP PRIMARY KEY (codigo_pedido,codigo_producto),
CONSTRAINT FK_DEP_PRO FOREIGN KEY (codigo_producto) REFERENCES PRODUCTO (codigo_producto),
CONSTRAINT FK_DEP_PED FOREIGN KEY (codigo_pedido) REFERENCES PEDIDO (codigo_pedido)

);




CREATE TABLE IF NOT EXISTS PAGO (
codigo_cliente INT (11),
forma_pago VARCHAR (40),
id_transaccion VARCHAR (50),
fecha_pago DATE,
total DECIMAL (15,2),
CONSTRAINT PK_CLI PRIMARY KEY (id_transaccion),
CONSTRAINT FK_PAG_CLI FOREIGN KEY (codigo_cliente) REFERENCES CLIENTE (codigo_cliente)
);


