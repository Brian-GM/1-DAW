DROP DATABASE EJERCICIO04;
CREATE DATABASE IF NOT EXISTS EJERCICIO04;

use EJERCICIO04;

CREATE TABLE FABRICANTE (
    codFabricante int auto_increment,
    nombre VARCHAR(32) NOT NULL,
    pais VARCHAR(32),
    CONSTRAINT PK_FAB_COD PRIMARY KEY (codFabricante)
);

CREATE TABLE ARTICULO(
    codigo VARCHAR(32),
    codFabricante int,
    peso DECIMAL(5,2),
    categoria ENUM ('primera', 'segunda','tercera'),
    precioVenta DECIMAL(5,2),
    precioCompra DECIMAL(5,2),
    existencias int,
    CONSTRAINT PK_AR PRIMARY KEY (codigo, codFabricante,peso,categoria),
    CONSTRAINT FK_AR_FA FOREIGN KEY (codFabricante) REFERENCES FABRICANTE(codFabricante),
    CONSTRAINT CK_AR_PE CHECK (peso>=0),
    CONSTRAINT CK_AR_VE CHECK (precioVenta>=0),
    CONSTRAINT CK_AR_CO CHECK (precioCompra>=0)
);

INSERT INTO FABRICANTE (nombre, pais) VALUES
("Muebles Balle", "España"),
("Lamparas LuceT","España"),
("Sofas Esclafón","España"),
("Decoración Art", "Italia"),
("Tarimas Flotante", "Francia");


INSERT INTO ARTICULO VALUES
('cod1',1,20.00,'primera',125.00,100.00,50), 
('cod2',3,45.00,'tercera',100.90,20.90,10),  
('cod3',2,20.00,'segunda',320.00,100.00,50), 
('cod4',3,45.00,'tercera',100.00,20.00,10), 
('cod5',5,12.25,'primera',250.99,99.99,100);

INSERT INTO FABRICANTE (nombre, pais) VALUES
('Forjados Forja','Rusia');

INSERT INTO ARTICULO VALUES
('cod6',last_insert_id(),60.00,'segunda',225.00,120.00,30);

