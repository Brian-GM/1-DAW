--Ejercicio 4
drop database if exists Biblioteca;
Create database If not exists Biblioteca default character set utf8 collate utf8_spanish_ci;

use Biblioteca;

CREATE TABLE libro (
	codigo int unsigned auto_increment primary key,
	titulo varchar(32) not null,
	autor varchar(32) not null,
	stock int unsigned default 0,
	genero enum ("INF","HIS","NOV")
);

CREATE TABLE prestamo(
	codLibro int unsigned,
	codSocio int unsigned,
	fentrega date,
	fdevolucion date,
	constraint PK_PR primary key (codLibro, codSocio, fentrega),
	constraint FK_PR_LIB foreign key (codLibro) references libro(codigo)
);