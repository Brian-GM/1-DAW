INSERT INTO libro VALUES
(1,'Historia de España','J. Pérez',5,'HIS'),
(2,'Reina Roja','J. Gómez-Jurado',33,'NOV');

INSERT INTO prestamo VALUES
(1,1,'2020-10-15',NULL),
(2,1,'2020-12-25',NULL);