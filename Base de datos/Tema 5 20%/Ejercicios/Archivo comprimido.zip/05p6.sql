ALTER TABLE libro DISABLE KEYS;
ALTER TABLE libro modify codigo int unsigned;
ALTER TABLE libro ADD CONSTRAINT UN_LI_COD UNIQUE (codigo);
ALTER TABLE libro DROP primary key;
ALTER TABLE libro ADD CONSTRAINT PK_LIB_TIT primary key (titulo);
ALTER TABLE libro ENABLE KEYS;
ALTER TABLE libro ADD CONSTRAINT CK_LIB_STO check(stock>=2);