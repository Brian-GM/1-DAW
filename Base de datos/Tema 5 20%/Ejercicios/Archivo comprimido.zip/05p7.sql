alter table prestamo 
	drop constraint FK_PR_LIB;
alter table prestamo
	add constraint FK_PR_LIB foreign key (codLibro) references libro(codigo) on delete cascade on update cascade;

delete from libro where titulo="Historia de España";
