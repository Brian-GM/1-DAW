DROP DATABASE IF EXISTS VENTAS;
CREATE DATABASE VENTAS;
USE VENTAS;

CREATE TABLE CLIENTE(
    id REAL AUTO_INCREMENT,
    nombre varchar(100) NOT NULL,
    apellido1 varchar(100) NOT NULL,
    apellido2 varchar(100),
    ciudad varchar(100),
    categoria int ,
    CONSTRAINT PK_CLI PRIMARY KEY(id)

);

CREATE TABLE COMERCIAL(
    id REAL AUTO_INCREMENT,
    nombre varchar(100) NOT NULL,
    apellido1 varchar(100) NOT NULL,
    apellido2 varchar(100),
    ciudad varchar(100),
    comision float (0000,00),
    CONSTRAINT PK_COM PRIMARY KEY(id)

);
CREATE TABLE PEDIDO(
    id REAL AUTO_INCREMENT,
    total float (000000,00)NOT NULL,
    fecha date,
    id_cliente REAL NOT NULL,
    id_comercial REAL NOT NULL,
    CONSTRAINT PK_PED PRIMARY KEY(id),
    CONSTRAINT FK_PED_CLI FOREIGN KEY (id_cliente) REFERENCES CLIENTE (id),
    CONSTRAINT FK_PED_COM FOREIGN KEY (id_comercial) REFERENCES COMERCIAL (id)



);

/*Da fallo porque  en la primera fila el id_cliente es 5 y en la segunda fila el id_comercial tambien es 5*/



















