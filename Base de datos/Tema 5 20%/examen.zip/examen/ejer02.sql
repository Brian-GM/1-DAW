USE VENTAS;
INSERT INTO cliente VALUES (LAST_INSERT_ID(1),'Aaron','Rivero','Gomez','Almeria',100);
INSERT INTO cliente VALUES (LAST_INSERT_ID(2),"Adela","Salas","Diaz","Granada",200);
INSERT INTO cliente VALUES (LAST_INSERT_ID(3),"Adolfo","Rubio","Flores","Sevilla",NULL);

INSERT INTO comercial (id,nombre,apellido1,apellido2,comision) VALUES (LAST_INSERT_ID(1),"Daniel","Saez","Vega",0.15);
INSERT INTO comercial (id,nombre,apellido1,apellido2,comision) VALUES (LAST_INSERT_ID(2),"Juan","Gomez","Lopez",0.13);
INSERT INTO comercial (id,nombre,apellido1,apellido2,comision) VALUES (LAST_INSERT_ID(3),"Diego","Flores",NULL,0.11);

INSERT INTO pedido VALUES (LAST_INSERT_ID(1),150.5,2017-10-05,5,2);
INSERT INTO pedido VALUES (LAST_INSERT_ID(2),270.65,2016-09-10,1,5);
INSERT INTO pedido VALUES (LAST_INSERT_ID(3),65.26,2017-10-05,2,1);
