/*1*/

/*2*/
UPDATE cliente SET categoria = 250 WHERE ciudad="Sevilla";
/*3*/
UPDATE pedido SET total = 0 WHERE fecha="2019-01-25";
UPDATE pedido SET total = 0 WHERE fecha="2019-03-11";

/*4*/
UPDATE comercial SET nombre="Maria" WHERE apellido1="Hernandez" or apellido2="Hernandez";
/*5*/
UPDATE cliente SET apellido2="Sin apellido" WHERE apellido2='NULL';
/*6*/

/*7*/
DELETE FROM pedido WHERE total<100;
/*8*/
DELETE FROM pedido WHERE id_cliente=10;
/*9*
DELETE FROM cliente WHERE categoria=100 or ciudad="Almeria";
*/


/*10*/
DELETE FROM pedido WHERE fecha="2015-09-10";
DELETE FROM pedido WHERE fecha="2015-06-27";


/*11
Truncate table vacia la tabla entera y delete from usando where puedes vaciar filas
*/
